import gradio as gr
from ultralytics import YOLO
import cv2
import numpy as np

# Load trained model
model = YOLO("runs/detect/train2/weights/best.pt")

def detect_objects(img):
    # Run detection
    results = model(img)[0]
    annotated_img = img.copy()
    detections = []

    for box in results.boxes:
        x1, y1, x2, y2 = map(int, box.xyxy[0])
        conf = box.conf[0].item()
        cls = int(box.cls[0].item())
        label = model.names[cls]
        cv2.rectangle(annotated_img, (x1, y1), (x2, y2), (0, 255, 0), 2)
        cv2.putText(annotated_img, f"{label} {conf:.2f}", (x1, y1 - 10),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)
        detections.append(f"{label} ({conf:.2%})")

    annotated_img = cv2.cvtColor(annotated_img, cv2.COLOR_BGR2RGB)

    # Combine all detections as string output
    output_text = "\n".join(detections) if detections else "No objects detected"
    return annotated_img, output_text

# Create Gradio interface
iface = gr.Interface(
    fn=detect_objects,
    inputs=gr.Image(type="numpy", label="Upload Image"),
    outputs=[
        gr.Image(type="numpy", label="Predicted Image"),
        gr.Textbox(label="Detected Objects (from yolo_params.yaml)", lines=4)
    ],
    title="🚀 Space Station Object Detector",
    description="Upload an image containing Toolbox, Oxygen Tank or Fire Extinguisher. The model will detect and show object names(from yolo_params.yaml) with confidence scores."
)

if __name__== "__main__":
    iface.launch(share=True)