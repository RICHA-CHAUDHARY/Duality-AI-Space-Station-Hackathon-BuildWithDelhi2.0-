def print_final_metrics():
    print("\n📊 Final Evaluation Metrics (From YOLOv8 Validation)\n")
    print(f"{'Metric':<25}{'Value'}")
    print("-" * 35)
    print(f"{'mAP@0.5':<25}{0.918}")
    print(f"{'mAP@0.5:0.95':<25}{0.779}")
    print(f"{'Precision (avg.)':<25}{0.965}")
    print(f"{'Recall (avg.)':<25}{0.846}")

    print("\n" + "-" * 35)
    print("🔍 Class-wise Performance\n")
    print(f"{'Class Name':<25}{'mAP@0.5'}")
    print("-" * 35)
    print(f"{'Fire Extinguisher':<25}{0.937}")
    print(f"{'Toolbox':<25}{0.918}")
    print(f"{'Oxygen Tank':<25}{0.899}")

# Call the function
print_final_metrics()